//
//  Section.swift
//  Haunt Hour
//
//  Created by KPS on 04/12/2023.
//

import Foundation

class Section : NSObject {

    var sectionName = ""
    var sectionText = ""
    var option1Text = ""
    var option2Text = ""
    var option1SectionName = ""
    var option2SectionName = ""

    init(sectionName: String = "", sectionText: String = "", option1Text: String = "", option2Text: String = "", option1SectionName: String = "", option2SectionName: String = "") {
        self.sectionName = sectionName
        self.sectionText = sectionText
        self.option1Text = option1Text
        self.option2Text = option2Text
        self.option1SectionName = option1SectionName
        self.option2SectionName = option2SectionName
    }
}
