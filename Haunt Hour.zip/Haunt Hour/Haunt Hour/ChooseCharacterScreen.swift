//
//  ChooseCharacterScreen.swift
//  Haunt Hour
//
//  
//

import Foundation
import UIKit

class ChooseCharacterScreen: UIViewController {

    @IBOutlet var ddCharacters : DropDown!
    @IBOutlet var lblCharaterDetails : UILabel!
    @IBOutlet var imgCharater : UIImageView!

    var charatersName : [String] = []

    var charatersDetail : [String] = []

    var charatersImage : [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        // The list of array to display. Can be changed dynamically
        self.charatersName = ["Astrid the Historian", "Vincent the Occultist", "Olivia the Survivor", "Gideon the Paranormal Investigator", "Elena the Medium"]
        self.charatersDetail = ["Strengths: Extensive knowledge of ancient civilizations, excellent puzzle-solving skills.\nWeaknesses: Physically frail, tends to overthink in high-pressure situations.",
        "Strengths: Proficient in dark arts, adept at sensing supernatural energies.\nWeaknesses: Susceptible to corruption by the malevolent forces, paranoia.",
        "Strengths: Exceptional agility, resourcefulness, heightened senses.\nWeaknesses: PTSD triggers, difficulty trusting others.",
        "Strengths: Advanced equipment for ghost detection, skepticism.\nWeaknesses: Fear of the unknown, overreliance on technology.",
        "Strengths: Ability to communicate with spirits, heightened intuition.\nWeaknesses: Vulnerability to possession, draining encounters with the supernatural."]
        self.charatersImage = ["astrid", "occultist", "survivor", "paranormal", "medium"]
        ddCharacters.optionArray = charatersName

        //Its Id Values and its optional
        ddCharacters.optionIds = [1,2,3,4,5]

        // The the Closure returns Selected Index and String
        ddCharacters.didSelect{(selectedText , index ,id) in
            self.ddCharacters.text = "\(selectedText)"
            self.lblCharaterDetails.text = self.charatersDetail[index]
            self.imgCharater.image = UIImage(named: self.charatersImage[index])

        }

        self.ddCharacters.text = self.charatersName[0]
        self.lblCharaterDetails.text = self.charatersDetail[0]
        self.ddCharacters.selectedIndex = 0
        self.imgCharater.image = UIImage(named: self.charatersImage[0])

    }


}
