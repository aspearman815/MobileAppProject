//
//  GameController.swift
//  Haunt Hour
//
//
//

import Foundation
import UIKit
import AVFAudio

class GameController: UIViewController {

    @IBOutlet var lblSectionText : UILabel!
    @IBOutlet var imgSection : UIImageView!
    @IBOutlet var lblOption1 : UILabel!
    @IBOutlet var lblOption2 : UILabel!
    @IBOutlet var btnOption1 : UIButton!
    @IBOutlet var btnOption2 : UIButton!

    var currentLevelSections : [Section] = []
    var currentSection : Section = DataManager.shared.nilSection
    var audioPlayer: AVAudioPlayer?

    var gameEndToken = ""

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillDisappear(_ animated: Bool) {
        self.stopMusic()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        if DataManager.shared.getSoundCheck() == true {
            self.startBackgroundMusic()
        }

        if DataManager.shared.getDifficultyLevel() == "Hard"{
            DataManager.shared.arrangeHardModeLevelData()
            self.currentLevelSections = DataManager.shared.hardSectionsArray
        }else{
            DataManager.shared.arrangeEasyModeLevelData()
            self.currentLevelSections = DataManager.shared.easySectionsArray
        }

        self.currentSection = currentLevelSections[0]
        self.populateCurrentSection()

    }

    func startBackgroundMusic() {
        if let bundle = Bundle.main.path(forResource: "LivingintheDark", ofType: "mp3") {
            let backgroundMusic = NSURL(fileURLWithPath: bundle)
            do {
                audioPlayer = try AVAudioPlayer(contentsOf:backgroundMusic as URL)
                guard let audioPlayer = audioPlayer else { return }
                audioPlayer.numberOfLoops = -1 // for infinite times
                audioPlayer.prepareToPlay()
                audioPlayer.play()
            } catch {
                print(error)
            }
        }
    }


    func stopMusic(){
        self.audioPlayer?.stop()
    }


    func populateCurrentSection(){
        self.lblSectionText.text = self.currentSection.sectionText
        self.lblOption1.text = self.currentSection.option1Text
        self.lblOption2.text = self.currentSection.option2Text
        let difficulty = DataManager.shared.getDifficultyLevel()

        if difficulty == "Easy" {
            self.imgSection.image = UIImage(named: self.currentSection.sectionName)
        }else{
            //Hard:
            self.imgSection.image = UIImage(named: "\(self.currentSection.sectionName)_H")
        }

    }


    @IBAction func btnOption1Clicked(_ sender : UIButton){

        if currentSection.option1SectionName == "Eclipse Consumed" || currentSection.option1SectionName == "Dark Ascendance" {
            //take to lose screen:
            self.gameEndToken = currentSection.option1SectionName
            self.performSegue(withIdentifier: "gameEnded", sender: self)
        }
        
        if currentSection.option1SectionName == "Eclipse Averted" {
            //take to win screen:
            self.gameEndToken = currentSection.option1SectionName
            self.performSegue(withIdentifier: "gameEnded", sender: self)
        }
        print("abcd: \(currentSection.option1SectionName)")
        let thisSection = self.findSectionWhereSectionNameIs(sectionName: currentSection.option1SectionName)
        self.currentSection = thisSection
        self.populateCurrentSection()
        
    }


    @IBAction func btnOption2Clicked(_ sender : UIButton){

        if currentSection.option2SectionName == "Eclipse Consumed" || currentSection.option2SectionName == "Dark Ascendance" {
            //take to lose screen:
            self.gameEndToken = currentSection.option2SectionName
            self.performSegue(withIdentifier: "gameEnded", sender: self)
        }

        if currentSection.option2SectionName == "Eclipse Averted" {
            //take to win screen:
            self.gameEndToken = currentSection.option2SectionName
            self.performSegue(withIdentifier: "gameEnded", sender: self)
        }

        print("abcd: \(currentSection.option2SectionName)")
        let thisSection = self.findSectionWhereSectionNameIs(sectionName: currentSection.option2SectionName)
        self.currentSection = thisSection
        self.populateCurrentSection()
    }


    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        if let destinationVC = segue.destination as? GameEndScreen {
            if self.gameEndToken == "Eclipse Consumed" || self.gameEndToken == "Dark Ascendance"{
                destinationVC.strTitle = "YOU LOSE"
                destinationVC.strEnding = self.gameEndToken
                destinationVC.strDetail = "The screen fades to black as the castle succumbs to the malevolent forces. The characters, now lost souls within its haunted halls, join the chorus of anguished whispers that echo through the darkness. Castle Eclipsis stands as a grim reminder of the failed attempt to avert the eclipse, its malevolent power growing stronger, spreading its darkness to the world beyond."
            }else{
                destinationVC.strTitle = "YOU WON"
                destinationVC.strDetail = "As you step through the castle gates, the oppressive atmosphere lifts, and the eclipsed sky begins to clear. The characters, though changed by the harrowing experience, stand together outside Castle Eclipsis. Behind them, the once foreboding structure crumbles, its malevolent forces quelled. The world outside awaits, and the characters, their bonds forged in the crucible of darkness, embark on the journey to rebuild their lives."
            }
        }
    }

    func findSectionWhereSectionNameIs(sectionName : String) -> Section {
        for i in 0..<self.currentLevelSections.count {
            if self.currentLevelSections[i].sectionName == sectionName {
                return self.currentLevelSections[i]
            }
        }
        return DataManager.shared.nilSection
    }

}
