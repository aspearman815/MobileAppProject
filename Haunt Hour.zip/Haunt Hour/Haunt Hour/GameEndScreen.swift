//
//  GameEndScreen.swift
//  Haunt Hour
//
//
//

import Foundation
import UIKit

class GameEndScreen: UIViewController {

    @IBOutlet var lblTitle : UILabel!
    @IBOutlet var lblDetail : UILabel!
    @IBOutlet var imgEnding : UIImageView!

    var strEnding = ""
    var strTitle = ""
    var strDetail = ""

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        self.lblTitle.text = self.strTitle
        self.lblDetail.text = self.strDetail

        if strTitle == "YOU LOSE" {
            self.lblTitle.textColor = .red
            self.imgEnding.image = UIImage(named: strEnding == "Eclipse Consumed" ? "Bad Ending 1" : "Bad Ending 2")
        }else{
            self.lblTitle.textColor = .green
            self.imgEnding.image = UIImage(named: "Good Ending 1")
        }
    }

    
    @IBAction func btnEndClicked(_ sender : UIButton){
        self.navigationController?.popToRootViewController(animated: true)
    }



}
