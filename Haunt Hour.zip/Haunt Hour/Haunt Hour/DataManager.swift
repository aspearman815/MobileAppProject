//
//  DataManager.swift
//  Werewolf
//
//  
//


import Foundation
import UIKit

struct UserDefaultKeys {
    static let difficultyLevel = "difficultyLevel"
    static let soundCheck = "soundCheck"
    
}


class DataManager: NSObject {
    
    static let shared = DataManager()

    var easySectionsArray : [Section] = []
    var hardSectionsArray : [Section] = []

    var nilSection = Section(sectionName: "", sectionText: "", option1Text: "", option2Text: "", option1SectionName: "", option2SectionName: "")
    
    fileprivate override init() {
        
    }

    func getDifficultyLevel() -> String {
        if let difficultyLevel = UserDefaults.standard.string(forKey: UserDefaultKeys.difficultyLevel) {
            return difficultyLevel
        }else{
            self.setDifficultyLevel(level: "Easy")
            return "Easy"
        }
    }


    func setDifficultyLevel(level : String){
        UserDefaults.standard.set(level, forKey: UserDefaultKeys.difficultyLevel)
    }


    func getSoundCheck() -> Bool {
        let soundCheck = UserDefaults.standard.bool(forKey: UserDefaultKeys.soundCheck)
        return soundCheck
    }


    func setSoundCheck(val : Bool){
        UserDefaults.standard.set(val, forKey: UserDefaultKeys.soundCheck)
    }


    func setAllTheLevelsIntoModelClassForEasySection(sectionNamesArray : [String], sectionText : [String], option1Text : [String], option2Text : [String], option1SectionName : [String], option2SectionName : [String]){

        self.easySectionsArray = []

        for i in 0..<sectionNamesArray.count {
            let sectionName = sectionNamesArray[i]
            let sectionText = sectionText[i]
            let option1Text = option1Text[i]
            let option2Text = option2Text[i]
            let option1SectionName = option1SectionName[i]
            let option2SectionName = option2SectionName[i]
            easySectionsArray.append(Section(sectionName: sectionName, sectionText: sectionText, option1Text: option1Text, option2Text: option2Text, option1SectionName: option1SectionName, option2SectionName: option2SectionName))
        }


    }

    func arrangeEasyModeLevelData(){

        let sectionNamesArray : [String] = ["Section Start", "Section A", "Section B", "Section C", "Section D", "Section E", "Section F", "Section G", "Section H", "Section I", "Section J", "Section K", "Section L", "Section M", "Section N", "Section O", "Section P", "Section Q",]

        let sectionText : [String] = [
                                      "As you enter the ancient library, you notice dusty shelves filled with mysterious books. Two books catch your eye. What will you do?",
                                      "As you enter the ancient library, you notice dusty shelves filled with mysterious books. Two books catch your eye. What will you do?",
                                      "The crypt is cold and foreboding. Two passages diverge in front of you. What will you choose",
                                      "The Tome of Symbols reveals intricate drawings. As you decipher them, a hidden door is hinted at. What's your next move?",
                                      "The Manuscript of Shadows details malevolent spirits. Suddenly, shadowy figures materialize. What do you do?",
                                      "The left passage twists and turns. A faint glow emanates from a distant room. What is your approach?", "You enter a hidden chamber with an altar. Two items lie on the altar. What do you choose?",
                                      "Your search reveals a concealed door. It appears locked. What's your next move?",
                                      "The ancient map is cryptic but points to a hidden passage. As you follow it, you encounter a cursed artifact. What will you do?",
                                      "As you confront the shadows, they lash out with malevolent energy. What's your reaction?",
                                      "You attempt to evade the shadows, but they pursue relentlessly. What's your desperate move?",
                                      "You cautiously navigate the twisting passage but trigger a hidden trap. What's your response?",
                                      "As you rush towards the glow, you find a chamber with an otherworldly presence. What's your approach?",
                                      "Taking the amulet, you feel an unnatural power coursing through you. What's your decision?",
                                      "As you examine the dagger, whispers in an ancient language fill your mind. What will you do?",
                                      "Your attempt to pick the lock triggers a trap. What's your reaction?", "You find a key, but it's engraved with ominous symbols. What will you do?",
                                      "Regardless of your choices, you find yourself at a crucial juncture. The castle seems to react to your decisions."]



        let option1Text : [String] = ["Explore the Library", "Read the Tome of Symbols", "Take the Left Passage", "Search for the Hidden Door", "Confront the Shadows", "Proceed with Caution", "Take the Mysterious Amulet", "Attempt to Pick the Lock", "Touch the Artifact", "Resist the Shadows", "Hide in the Shadows", "Attempt to Disarm the Trap", "Communicate with the Presence", "Embrace the Power", "Take the Dagger and Speak the Words", "Dodge the Trap", "Use the Key to Unlock the Door", "Continue Towards the Exit"]

        let option1SectionName : [String] = ["Section A", "Section C", "Section E", "Section G", "Section I", "Section K", "Section M", "Section O", "Eclipse Consumed", "Section Q", "Eclipse Consumed", "Section Q", "Section Q", "Dark Ascendance", "Dark Ascendance", "Section Q", "Section Q", "Eclipse Averted"]



        let option2Text : [String] = ["Investigate the Crypt", "Study the Manuscript of Shadows", "Enter the Hidden Chamber", "Consult the Ancient Map", "Evade and Retreat", "Rush Towards the Glow", "Examine the Ancient Dagger", "Search for a Key", "Bypass the Artifact", "Submit to the Shadows", "Sprint Towards the Light", "Brace for Impact", "Attack the Presence", "Discard the Amulet", "Resist the Whispers and Leave the Dagger", "Get Caught in the Trap ", "Search for an Alternative Route", "Confront the Malevolent Force"]

        let option2SectionName : [String] = ["Section B", "Section D", "Section F", "Section H", "Section J", "Section L", "Section N", "Section P", "Section Q", "Dark Ascendance", "Section Q", "Eclipse Consumed", "Dark Ascendance", "Section Q", "Section Q", "Eclipse Consumed", "Section R", "Dark Ascendance"]

        self.setAllTheLevelsIntoModelClassForEasySection(sectionNamesArray: sectionNamesArray, sectionText: sectionText, option1Text: option1Text, option2Text: option2Text, option1SectionName: option1SectionName, option2SectionName: option2SectionName)

    }







    func setAllTheLevelsIntoModelClassForHardSection(sectionNamesArray : [String], sectionText : [String], option1Text : [String], option2Text : [String], option1SectionName : [String], option2SectionName : [String]){

        self.hardSectionsArray = []

        for i in 0..<sectionNamesArray.count {
            let sectionName = sectionNamesArray[i]
            let sectionText = sectionText[i]
            let option1Text = option1Text[i]
            let option2Text = option2Text[i]
            let option1SectionName = option1SectionName[i]
            let option2SectionName = option2SectionName[i]
            hardSectionsArray.append(Section(sectionName: sectionName, sectionText: sectionText, option1Text: option1Text, option2Text: option2Text, option1SectionName: option1SectionName, option2SectionName: option2SectionName))
        }

    }

    
    func arrangeHardModeLevelData(){
        let sectionNamesArray : [String] = ["Section A", "Section B", "Section C", "Section D", "Section E", "Section F", "Section G", "Section H", "Section I", "Section J", "Section K", "Section L", "Section M", "Section N", "Section O", "Section P", "Section Q", "Section R", "Section S"]

        let sectionText : [String] = [
                                    "As you enter the ancient library, the dusty shelves loom with an oppressive aura. Mysterious tomes line the walls, but two stand out among the shadows. What's your approach?",
                                      "The crypt's cold air chills your bones as two passages stretch ahead, shrouded in darkness. Your choice awaits.",
                                      "The Glyph-Encrusted Codex reveals intricate symbols, each demanding careful analysis. What's your strategy?",
                                    "The Whispering Folio emits eerie sounds as you approach. The whispers carry secrets. How do you proceed?",
                                    "The ominous corridor seems to close in on you. A distant glow beckons, but shadows dance menacingly. What's your course?",
                                    "Descending into the echoing abyss, the air grows thicker. Two paths diverge within the abyss. Which will you choose?",
                                    "As you meticulously analyze the symbols, time seems to slip away. What's your response to the growing tension?",
                                    "Your intuition guides you, but the symbols blur together. A sense of urgency takes hold. What's your decision?",
                                    "The loudest whispers lead you to a hidden passage. The air becomes suffocating. What's your reaction?",
                                    "Listening to all whispers, patterns emerge but become overwhelming. How do you cope with the increasing intensity?",
                                    "Facing the shadows head-on, their malevolent energy intensifies. What's your strategy against this rising darkness?",
                                    "Choosing the stealthy path, shadows seem to lurk everywhere. A distant, ominous hum echoes. How do you proceed?",
                                    "Taking the amulet, a surge of dark power courses through you. The walls seem to pulsate with malevolence. What's your next move?",
                                    "Examining the ancient dagger, whispers in an ancient language become almost deafening. How do you react to this overwhelming force?",
                                    "As you maintain focus despite the pressure, the symbols reveal a hidden passage. The path seems treacherous. What's your approach?",
                                    "Hastily concluding the analysis, you unlock a hidden passage. It leads to a chamber with an unsettling aura. What's your decision?",
                                    "Regardless of your choices, you find yourself at a crucial juncture. The castle seems to react to your decisions.",
                                    "Deviating from the path, you find an alternative route. The air grows dense, and the path seems unfamiliar. What's your strategy?",
                                    "The path leads to a mysterious chamber. An eerie glow illuminates the surroundings. What's your next move?"]



        let option1Text : [String] = ["Decipher the Glyph-Encrusted Codex", "Navigate the Ominous Corridor", "Dedicate Time to Analyze Every Symbol", "ocus on the Loudest Whispers for Clues ", "Face the Shadows Head-On", "Ascend to the Shadows' Source", "Maintain Focus Despite the Pressure", "Trust Your Instincts and Forge Ahead", "Press Onward Despite the Discomfort", "Embrace the Overwhelming Whispers", "Summon Inner Strength and Confront the Shadows", "Move Stealthily Towards the Hum", "Embrace the Dark Power and Confront the Shadows", "Take the Dagger and Attempt the Incantation", "Navigate the Treacherous Path with Caution", "Enter the Chamber with Caution", "Press Forward to Confront the Malevolent Force ", "Navigate the Unfamiliar Path with Caution", "Confront the Enigma Within the Chamber "]

        let option1SectionName : [String] = ["Section C", "Section E", "Section G", "Section I", "Section K", "Section K", "Section O", "Section O", "Section Q", "Section Q", "Section Q", "Section Q", "Section Q", "Section Q", "Section Q", "Section Q", "Dark Ascendance", "Section Q", "Dark Ascendance"]



        let option2Text : [String] = ["Examine the Whispering Folio", "Descend into the Echoing Abyss", "Rely on Intuition to Speed Up the Process", "Listen to All Whispers and Interpret Patterns ", "Find a Stealthy Path Through the Shadows ", "Descend Further into the Abyss", "Hastily Conclude the Analysis", "Double-Check Every Interpretation", "Retreat and Seek Another Route", "Block Out the Whispers and Focus on Patterns", "Retreat and Search for an Alternative Path", "Distract the Shadows and Deviate from the Path", "Resist the Dark Influence and Flee", "Resist the Overpowering Whispers and Abandon the Dagger", "Brave the Path with Swift Determination", "Enter the Chamber with Confidence", "Retreat and Seek an Alternative Route", "Press Forward with Determination", "Seek a Hidden Exit Within the Chamber"]

        let option2SectionName : [String] = ["Section D", "Section F", "Section H", "Section J", "Section L", "Section L", "Section P", "Section P", "Section R", "Section R", "Section R", "Section R", "Section R", "Section R", "Section S", "Section S", "Section S", "Eclipse Consumed", "Eclipse Averted"]


        self.setAllTheLevelsIntoModelClassForHardSection(sectionNamesArray: sectionNamesArray, sectionText: sectionText, option1Text: option1Text, option2Text: option2Text, option1SectionName: option1SectionName, option2SectionName: option2SectionName)

    }

}


extension UIViewController {

    @IBAction func btnBackClicked(_ sender : UIButton){
        self.navigationController?.popViewController(animated: true)
    }


}
