//
//  SettingsController.swift
//  Haunt Hour
//
//  
//

import Foundation
import UIKit

class SettingsController : UIViewController {

    @IBOutlet var swSoundCheck : UISwitch!
    @IBOutlet var lblDifficulty : UILabel!
    @IBOutlet var segDifficultyLevel : UISegmentedControl!

    override func viewDidLoad() {
        super.viewDidLoad()
        segDifficultyLevel.addTarget(self, action: #selector(segmentedControlValueChanged(_:)), for: .valueChanged)

    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        self.swSoundCheck.isOn = DataManager.shared.getSoundCheck()
        self.lblDifficulty.text = DataManager.shared.getDifficultyLevel()

    }

    @IBAction func toggleSound(_ sender: UISwitch) {
        if(sender.isOn) {
            DataManager.shared.setSoundCheck(val: true)
            sender.isOn = true
        } else {
            DataManager.shared.setSoundCheck(val: false)
            sender.isOn = false
        }
    }

    @objc func segmentedControlValueChanged(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            DataManager.shared.setDifficultyLevel(level: "Easy")
            self.lblDifficulty.text = "Easy"
        }
//        else if sender.selectedSegmentIndex == 1 {
//            DataManager.shared.setDifficultyLevel(level: "Medium")
//            self.lblDifficulty.text = "Medium"
//        }
        else{
            DataManager.shared.setDifficultyLevel(level: "Hard")
            self.lblDifficulty.text = "Hard"
        }

    }


}

